package com.sonnik.cep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerEngagementPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
