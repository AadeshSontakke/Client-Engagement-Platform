package com.sonnik.cep.controller;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sonnik.cep.entity.Customer;
import com.sonnik.cep.service.CustomerService;

@RestController
@RequestMapping("/api")
public class CustomerController {
	
	private CustomerService service;
	
	public CustomerController(CustomerService service) {
		super();
		this.service = service;
	}


	@PostMapping("/insert")
	public String insertCustomer(@RequestBody Customer customer)
	{
		 return service.insertCustomer(customer);
		
	}
	
	@GetMapping
	public List<Customer> getCustomerList()
	{
		return service.getCustomerList();
	}
	
	@GetMapping("/{id}")
	public Customer getCustomerById(@PathVariable int id)
	{
		return service.getCustomerById(id);
	}
	
	@PutMapping
	public String updateCustomer(@RequestBody Customer customer)
	{
		return service.updateCustomer(customer);
	}
	
	@DeleteMapping("/{id}")
	public String deleteCustomer(@PathVariable int id)
	{
		
		return service.deleteCustomer(id);
	}
	
	@PostMapping("/home")
	public String insertMultipleCustomer(@RequestBody List<Customer> customers)
	{
		return service.insertMultipleCustomer(customers);
	}
	
	@GetMapping("/byname/{firstName}")
	public List<Customer> getCustomerByFirstName(@PathVariable String firstName)
	{
		return service.getCustomerByFirstName(firstName);
	}
	
	@GetMapping("/bylastname/{lastName}")
	public List<Customer> getCustomerByLastName(@PathVariable String lastName)
	{
		return service.getCustomerByLastName(lastName);
	}
	
	@GetMapping("/lessthanage/{age}")
	public List<Customer> getCustomerByLessThanAge(@PathVariable int age)
	{
		return service.getCustomerByLessThanAge(age);
	}
	
	@GetMapping("/more/{age}")
	public List<Customer> getCustomerByGreaterThanAge(@PathVariable int age)
	{
		return service.getCustomerBygreaterThanAge(age);
	}
	
	@GetMapping("/getbyage/{age}")
	public List<Customer> getCustomerByAge(@PathVariable int age)
	{
		return service.getCustomerByAge(age);
	}
	
	@GetMapping("/getbyemail/{email}")
	public List<Customer> getCustomerByEmail(@PathVariable String email)
	{
		return service.getCustomerByEmail(email);
				
	}
	
	@GetMapping("/getbyno/{mobileNo}")
	public List<Customer> getCustomerByMobileNo(@PathVariable String mobileNo)
	{
		return service.getCustomerByMobileNo(mobileNo);
	}
	
	@PutMapping("/{id}")
	public String updateByFirstName(@PathVariable int id , @RequestBody Map<String, String> request)
	{
		String firstName = request.get("firstName");
		return service.updateByFirstName(id, firstName);
	}
	
	@PutMapping("/bylastname/{id}")
	public String updateByLastName(@PathVariable int id , @RequestBody Map<String, String> request)
	{
		String lastName = request.get("lastName");
		return service.updateByLastName(id, lastName);
		
	}
	
	@PutMapping("/updatebyemail/{id}")
	public String updateByEmail(@PathVariable int id , @RequestBody Map<String , String> request)
	{
		String email = request.get("email");
		return service.updateByEmail(id, email);
	}
	
	@PutMapping("/updatebymobile/{id}")
	public String updateByMobileNo(@PathVariable int id , @RequestBody Map<String, String> request)
	{
		String mobileNo = request.get("mobileNo");
		return service.updateByMobileNo(id, mobileNo);
	}

	@PutMapping("/updatebyage/{id}")
	public String updateByAge(@PathVariable int id , @RequestBody Map<String, Integer> request)
	{
		int age = request.get("age");
		return service.updateByAge(id, age);
	}
	
	@GetMapping("/getbyfirstname")
	public List<String> getFirstNameofCustomers()
	{
		return service.getFirstNameofCustomers();
	}
	
	@GetMapping("/getbylastname")
	public List<String> getLastName()
	{
		return service.getLastName();
	}
	
}
