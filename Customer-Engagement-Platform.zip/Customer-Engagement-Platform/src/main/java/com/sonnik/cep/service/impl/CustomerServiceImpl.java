package com.sonnik.cep.service.impl;

import java.util.List;

import org.springframework.aop.aspectj.InstantiationModelAwarePointcutAdvisor;
import org.springframework.stereotype.Service;

import com.sonnik.cep.entity.Customer;
import com.sonnik.cep.repository.CustomerRepository;
import com.sonnik.cep.service.CustomerService;
@Service
public class CustomerServiceImpl implements CustomerService{

	private CustomerRepository repository;
	
	public CustomerServiceImpl(CustomerRepository repository) {
		super();
		this.repository = repository;
	}


	@Override
	public String insertCustomer(Customer customer) {

		String message = repository.insertCustomer(customer);
		return message;
	}


	@Override
	public List<Customer> getCustomerList() {
		return  repository.getCustomerList();
		
		
	}


	@Override
	public Customer getCustomerById(int id) {

		return repository.getCustomerById(id);
	}


	@Override
	public String updateCustomer(Customer customer) {
		
		return repository.updateCustomer(customer);
	}


	@Override
	public String deleteCustomer(int id) {
		return repository.deleteCustomer(id);
	}


	@Override
	public String insertMultipleCustomer(List<Customer> customers) {
		return repository.insertMultipleCustomer(customers);
	}


	@Override
	public List<Customer> getCustomerByFirstName(String firstName) {
		return repository.getCustomerByFirstName(firstName);
	}


	@Override
	public List<Customer> getCustomerByLastName(String lastName) {
		return repository.getCustomerByLastName(lastName);
	}


	@Override
	public List<Customer> getCustomerByLessThanAge(int age) {
		return repository.getCustomerByLessThanAge(age);
	}


	@Override
	public List<Customer> getCustomerBygreaterThanAge(int age) {
		return repository.getCustomerByGreaterThanAge(age);
	}


	@Override
	public List<Customer> getCustomerByAge(int age) {
		return repository.getCustomerByAge(age);
	}


	@Override
	public List<Customer> getCustomerByEmail(String email) {
		return repository.getCustomerByEmail(email);
	}


	@Override
	public List<Customer> getCustomerByMobileNo(String mobileNo ) {
		return repository.getCustomerByMobileNo(mobileNo);
	}


	@Override
	public String updateByFirstName(int id, String firstName) {
		return repository.UpdateByFirstName(id, firstName);
	}


	@Override
	public String updateByLastName(int id, String lastName) {
		return repository.updateByLastName(id, lastName);
	}


	@Override
	public String updateByEmail(int id, String email) {
		return repository.updateByEmail(id, email);
	}


	@Override
	public String updateByMobileNo(int id, String mobileNo) {
		return repository.updateByMobileNo(id, mobileNo);
	}


	@Override
	public String updateByAge(int id, int age)
	{
		return repository.updateByAge(id, age);
	}


	@Override
	public List<String> getFirstNameofCustomers() {
		return repository.getFirstNameofCustomers();
	}


	@Override
	public List<String> getLastName() {
		return repository.getLastName();
	}


	

}
