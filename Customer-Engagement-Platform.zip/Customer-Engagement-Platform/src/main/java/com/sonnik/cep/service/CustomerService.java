package com.sonnik.cep.service;

import java.util.List;

import com.sonnik.cep.entity.Customer;

public interface CustomerService {
	
	String insertCustomer(Customer customer);
	
	List<Customer> getCustomerList();
	
	Customer getCustomerById(int id );
	
	String updateCustomer(Customer customer);
	
	String deleteCustomer(int id);
	
	String insertMultipleCustomer(List<Customer> customers);
	
	List<Customer> getCustomerByFirstName(String firstName);
	
	List<Customer> getCustomerByLastName(String lastName);
	
	List<Customer> getCustomerByLessThanAge(int age);
	
	List<Customer> getCustomerBygreaterThanAge(int age);
	
	List<Customer> getCustomerByAge(int age);
	
	List<Customer> getCustomerByEmail(String email);
	
	List<Customer> getCustomerByMobileNo(String mobileNo);
	
	String updateByFirstName(int id, String firstName);
	
	String updateByLastName(int id , String lastName);
	
	String updateByEmail(int id,String email);
	
	String updateByMobileNo(int id,String mobileNo);
	
	String updateByAge(int id, int age);
	
	List<String> getFirstNameofCustomers();
	List<String> getLastName();
	

}
